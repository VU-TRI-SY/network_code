/*
 * TODO: define error code in this file
 */
#define TFTP_ERROR_INVALID_ARGUMENT_COUNT 11
#define TFTP_ERROR_INVALID_OPCODE 12
